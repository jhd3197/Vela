// App-owned persistence and a durable, explicitly retried action outbox.
window.MealsEngine = function (defaults, render) {
  let value = defaults, revision = 0, loaded = false, dirty = false, busy = false, conflict = false, pending = Promise.resolve();
  const status = document.getElementById('dataStatus');
  const controls = () => { document.getElementById('listView').inert = !loaded || busy || conflict; document.getElementById('detailView').inert = !loaded || busy || conflict; };
  const dirtyState = async next => { dirty = next; await Vela.setUnsavedChanges(next); };
  async function read() {
    const saved = await Vela.storage.read(); value = saved.value || structuredClone(defaults); revision = saved.revision;
    loaded = true; conflict = false; render(value); controls(); status.textContent = 'Saved to your engine';
    document.getElementById('recovery').hidden = true;
    document.getElementById('retrySend').hidden = value.outbox?.state !== 'pending';
  }
  function save(next = value) {
    if (busy) return pending;
    if (conflict || !loaded) return Promise.reject(Error('Resolve storage changes before saving'));
    value = next; busy = true; controls(); status.textContent = 'Saving…';
    pending = (async () => { try {
      await dirtyState(true); const saved = await Vela.storage.write(value, revision); revision = saved.revision;
      await dirtyState(false); status.textContent = 'Saved to your engine';
    } catch (error) { conflict = true; status.textContent = error.status === 409 ? 'Another client saved changes. Your edits are retained below.' : 'Not saved: ' + error.message; document.getElementById('recovery').hidden = false; document.getElementById('draftData').value = JSON.stringify(value, null, 2); throw error; }
    finally { busy = false; controls(); } })(); pending.catch(() => {}); return pending;
  }
  Vela.onSave(() => busy ? pending : save());
  document.getElementById('reloadData').onclick = async () => { try { await read(); await dirtyState(false); } catch (error) { status.textContent = error.message; } };
  Vela.ready.then(read).catch(error => { status.textContent = error.message; });
  setInterval(async () => { if (!loaded || dirty || busy || conflict || document.hidden) return; try { const saved = await Vela.storage.read(); if (dirty || busy || conflict) return; if (saved.revision !== revision) { value = saved.value || structuredClone(defaults); revision = saved.revision; render(value); } } catch (error) { status.textContent = 'Disconnected; showing last loaded data'; } }, 3000);
  let sending = false;
  async function send(input) {
    const message = document.getElementById('actionStatus');
    if (sending) return; sending = true;
    try {
      if (busy) await pending;
      if (!loaded || conflict) throw Error('Resolve your saved data first');
      if (value.outbox?.state === 'pending') {
        if (input && JSON.stringify(input) !== JSON.stringify(value.outbox.input)) throw Error('Retry the unfinished send before sending different content');
      } else {
        if (!input) return;
        value.outbox = { key: crypto.randomUUID(), input, state: 'pending' }; await save();
      }
      document.getElementById('retrySend').hidden = false;
      message.textContent = 'Sending to Notes…';
      const receipt = await Vela.actions.invoke('notes', 'create-note', value.outbox.input, value.outbox.key);
      value.outbox.state = 'succeeded'; await save();
      document.getElementById('retrySend').hidden = true;
      message.textContent = (receipt.replayed ? 'Confirmed earlier send' : 'Created in Notes') + ' · ' + receipt.executionId;
    } catch (error) { message.textContent = error.message + ' Use Retry unfinished send after resolving the problem.'; }
    finally { sending = false; }
  }
  document.getElementById('retrySend').onclick = () => send();
  return { save, send, get value() { return value; }, get editable() { return loaded && !busy && !conflict; } };
};
