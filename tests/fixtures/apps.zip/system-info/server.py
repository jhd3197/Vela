"""Tiny stdlib-only HTTP server returning system information as JSON.

Usage: python server.py <port>
"""

import json
import os
import platform
import sys
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

STARTED_AT = time.monotonic()


def memory_info():
    try:
        import psutil

        vm = psutil.virtual_memory()
        return {"total_bytes": vm.total, "available_bytes": vm.available, "source": "psutil"}
    except ImportError:
        pass
    if os.name == "posix":
        try:
            total = os.sysconf("SC_PHYS_PAGES") * os.sysconf("SC_PAGE_SIZE")
            return {"total_bytes": total, "available_bytes": None, "source": "os.sysconf"}
        except (ValueError, OSError, AttributeError):
            return None
    if os.name == "nt":
        import ctypes
        from ctypes import wintypes

        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ("dwLength", wintypes.DWORD),
                ("dwMemoryLoad", wintypes.DWORD),
                ("ullTotalPhys", ctypes.c_uint64),
                ("ullAvailPhys", ctypes.c_uint64),
                ("ullTotalPageFile", ctypes.c_uint64),
                ("ullAvailPageFile", ctypes.c_uint64),
                ("ullTotalVirtual", ctypes.c_uint64),
                ("ullAvailVirtual", ctypes.c_uint64),
                ("ullAvailExtendedVirtual", ctypes.c_uint64),
            ]

        stat = MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
            return {
                "total_bytes": stat.ullTotalPhys,
                "available_bytes": stat.ullAvailPhys,
                "source": "ctypes",
            }
    return None


def system_info():
    return {
        "platform": platform.platform(),
        "system": platform.system(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
        "memory": memory_info(),
        "python_version": platform.python_version(),
        "uptime_seconds": round(time.monotonic() - STARTED_AT, 3),
    }


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        body = json.dumps(system_info(), indent=2).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), format % args))


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8802
    server = HTTPServer(("127.0.0.1", port), Handler)
    print(f"system-info listening on http://127.0.0.1:{port}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
